import random 
import string
def code(n):
    list = ""
    while n >=1:
        randomletter = random.choice(string.ascii_lowercase)
        if randomletter not in list:
            list += randomletter
            n -=1
        else:
            n=n
    print(list)

code(7)