def separe(mo):
    mo1 = ""
    for i in mo :
        mo1 = mo1 + i +","
    print (mo1)
separe("haiti")