def tiple(mo1,mo2):
    t = (mo2,mo1)
    print(t)
tiple("jacmel","Delmas")