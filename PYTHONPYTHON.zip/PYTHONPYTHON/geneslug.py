import string

def genere(fraz):
    slug =""
    for i in fraz:
        if i in (string.ascii_letters + string.digits + "_"):
            slug += i
    print(slug)

genere("Salut---  _comment@_tu   $%^_vas")
