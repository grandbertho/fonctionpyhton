import string


def kripte(mo):
    repons=""
    for i in mo:
        r = string.ascii_lowercase.index(i.lower())
        t = str(r)
        repons += t+"-"
    print(repons)
kripte("alo")