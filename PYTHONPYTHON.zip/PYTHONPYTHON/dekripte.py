import string
def dekripte(mo):
    reponse = ""
    mo1 = mo.split("-")
    for i in mo1:
        t = int(i)
        reponse += string.ascii_uppercase[t]
    print(reponse)

dekripte("0-11-14")