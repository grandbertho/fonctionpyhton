import re
def initial(nom):
    rezilta =""
    lis = re.split(r' |-',nom)
    for i in lis:
        rezilta += i[0]
    print(rezilta)
initial("Jean-Michel Bertho")    